package example

import java.util.concurrent.TimeUnit

import io.gatling.http.Predef._
import io.gatling.core.Predef._

import scala.concurrent.duration.Duration
class BasicSimulation extends Simulation {
  val httpConf = http.baseUrl("http://localhost:8080")
  val scn = scenario("Basic Simulation").repeat(1,"n") {
    exec(http("request_1")
      .post("/link?url=https://www.google.com"))
      .pause(3)
  }
      .repeat(300,"n") {
          exec(
            http("Creando Click")
              .get("/50328aa4")
          ).pause(Duration.apply(30, TimeUnit.MILLISECONDS))
      }
      .repeat(10, "n") {
        exec(
          http("Paginacion")
            .get("/all?size=10&page=${n}")
        ).pause(Duration.apply(300, TimeUnit.MILLISECONDS))
      }
    .repeat(10, "n") {
      exec(
        http("Ventana Temporal")
          .get("/all?start=1970-01-01T00%3A00&end=2020-11-14T22%3A42")
      ).pause(Duration.apply(300, TimeUnit.MILLISECONDS))
    }
    .repeat(1, "n") {
      exec(
        http("Ventana Temporal")
          .get("/download-data")
      ).pause(Duration.apply(3000, TimeUnit.MILLISECONDS))
    }
  setUp(
    scn.inject(atOnceUsers(1))
  ).protocols(httpConf)
}